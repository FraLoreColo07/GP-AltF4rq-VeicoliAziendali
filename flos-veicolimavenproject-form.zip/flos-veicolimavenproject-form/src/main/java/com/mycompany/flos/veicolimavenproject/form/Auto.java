/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.flos.veicolimavenproject.form;

import java.sql.Date;

/**
 * @author Giovanni F. Cappellini
 * @version 1.0
 * @file Auto.java
 * @brief Il file Auto.java contiene la classe \cAuto
 */

/**
 * @class Auto
 * @brief La classe gestisce le caratteristiche di un'auto aziendale
 * 
 * La classe collabora con \cDate
 */
class Auto 
{
    /**Targa di un'auto aziendale*/
    private String targa;
    
    /**Modello di un'auto aziendale*/
    private String modello;
    
    /**Marca che ha prodotto un'auto aziendale*/
    private String marca;
    
    /**Data in cui è stata revisionata un'auto aziendale*/
    private Date dataRevisone;
    
    /**Data in cui è stata acquistata un'auto aziendale*/
    private Date dataAcquisto;
    
    /**Immagine di un'auto aziendale*/
    private String img;
    
    /**Status di un'auto aziendale*/
    private String status;
    
    /**
     * @brief Costruttore con parametri
     * 
     * @param targa
     * @param modello
     * @param marca
     * @param dataRevisone
     * @param dataAcquisto
     * @param img
     * @param status 
     * 
     * Vengono inserite le caratteristiche di un'auto aziendale
     */
    public Auto(String targa, String modello, String marca, Date dataRevisone, Date dataAcquisto, String img, String status) 
    {
        this.targa = targa;
        this.modello = modello;
        this.marca = marca;
        this.dataRevisone = dataRevisone;
        this.dataAcquisto = dataAcquisto;
        this.img = img;
        this.status = status;
    }
   
    /**
     * @brief Metodo che restituisce la \ctarga di un'auto aziendale
     * 
     * @return targa
     */
    public String getTarga() 
    {
        return targa;
    }
    
    /**
     * @brief Metodo che modifica la \ctarga di un'auto aziendale
     * 
     * @param targa 
     */
    public void setTarga(String targa) 
    {
        this.targa = targa;
    }
    
    /**
     * @brief Metodo che restituisce il \cmodello di un'auto aziendale
     * 
     * @return modello
     */
    public String getModello() 
    {
        return modello;
    }
    
    /**
     * @brief Metodo che modifica il \cmodello di un'auto aziendale
     * 
     * @param modello 
     */
    public void setModello(String modello) 
    {
        this.modello = modello;
    }
    
    /**
     * @brief Metodo che restituisce la marca di un'auto aziendale
     * 
     * @return marca
     */
    public String getMarca() 
    {
        return marca;
    }
    
    /**
     * @brief Metodo che modifica la \cmarca di un'auto aziendale
     * 
     * @param marca 
     */
    public void setMarca(String marca) 
    {
        this.marca = marca;
    }
    
    /**
     * @brief Metodo che restituisce la \cdata della revisione di un'auto aziendale
     * 
     * @return dataRevisone
     */
    public Date getDataRevisone() 
    {
        return dataRevisone;
    }
    
    /**
     * @brief Metodo che modifica la \cdata della revisione di un'auto aziendale
     * 
     * @param dataRevisone 
     */
    public void setDataRevisone(Date dataRevisone) 
    {
        this.dataRevisone = dataRevisone;
    }
    
    /**
     * @brief Metodo che restituisce la \cdata dell'acquisto di un'auto aziendale
     * 
     * @return dataAcquisto
     */
    public Date getDataAcquisto() {
        return dataAcquisto;
    }
    
    /**
     * @brief Metodo che modifica la \cdata dell'acquisto di un'auto aziendale
     * 
     * @param dataAcquisto 
     */
    public void setDataAcquisto(Date dataAcquisto) 
    {
        this.dataAcquisto = dataAcquisto;
    }
    
    /**
     * @brief Metodo che restituisce l'\cimmagine di un'auto aziendale
     * 
     * @return img 
     */
    public String getImg() 
    {
        return img;
    }
    
    /**
     * @brief Metodo che modifica l'\cimmagine di un'auto aziendale
     * 
     * @param img 
     */
    public void setImg(String img) 
    {
        this.img = img;
    }
    
    /**
     * @brief Metodo che restituisce lo \cstatus di un'auto aziendale
     * 
     * @return status
     */
    public String getStatus() 
    {
        return status;
    }
    
    /**
     * @brief Metodo che modifica lo \cstatus di un'auto aziendale
     * 
     * @param status 
     */
    public void setStatus(String status) 
    {
        this.status = status;
    }
    
    /**
     * @brief Costruttore di default
     * 
     * Vengono inizializzati gli attributi
     */
    public Auto() 
    {
        this.targa = "";
        this.modello = "";
        this.marca = "";
        this.dataRevisone = null;
        this.dataAcquisto = null;
        this.img = "";
        this.status = "";
    } 
}