/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.flos.veicolimavenproject.form;

import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import org.json.JSONArray;
import org.json.JSONObject;

/**
 *
 * @author Giovanni F. Cappellini
 * @version 1.0
 * @file JSONfileParser.java
 * @brief Il file JSONfileParser.java contiene la classe \cJSONfileParser
 */

/**
 * @class JSONfileParser
 * @brief La classe gestisce la conversione del file JSON
 * 
 * La classe collabora con \cJSONObject, \cJSONArray e \cCharset
 */
class JSONfileParser 
{
    /**
     * @brief Metodo che converte il file JSON in stringhe dato il parametro inputFile
     * @param inputFile
     * @throws eccezioni di input/output (IOException)
     */
    public void parse(String inputFile) throws IOException 
    {        
        String allInputFile = this.readFile(inputFile,
                StandardCharsets.UTF_8);
        JSONObject obj = new JSONObject(allInputFile);
        if (obj != null) 
        {
            JSONArray dataset = obj.optJSONArray("items");
            if (dataset != null) 
            {
                for (int i = 0; i < dataset.length(); i++) 
                {
                    JSONObject current = dataset.optJSONObject(i);

                    //flat objects
                    if (current.get("kind") != null) 
                    {
                        System.out.println(current.get("kind").toString());
                    }
                    
                    //sub-objects
                    JSONObject subObject;
                    if (current.get("pagemap") != null) 
                    {
                        subObject = current.optJSONObject("pagemap");
                        if (subObject.get("citation_title") != null) 
                        {
                            System.out.println(subObject.get("citation_title").toString());
                        }
                    }
                }
            }
        }
    }
    
    /**
     * @brief Metodo che legge il file
     * @param path
     * @param encoding
     * @return file letto
     * @throws IOException 
     */
    private String readFile(String path, Charset encoding)
            throws IOException 
    {
        byte[] encoded = Files.readAllBytes(Paths.get(path));
        return new String(encoded, encoding);
    }
}