/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.flos.veicolimavenproject.form;

import java.math.BigInteger;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.HashMap;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * @author Giovanni F. Cappellini
 * @version 1.0
 * @file MyQuery.java
 * @brief Il file MyQuery.java contiene la classe \cMyQuery
 */

/**
 * @class MyQuery
 * @brief La classe gestisce la connessione al database
 * 
 * La classe collabora con \cMyConnection, \cMap, \cMessageDigest, \cBitInteger e \cUtilizzo
 */
public class MyQuery 
{
    /**Connessione al database*/
    private MyConnection conn;
    
    /**
     * @brief Costruttore di default
     */
    public MyQuery() 
    {
        conn = new MyConnection();
    }

    /**
     * @brief Metodo che restituisce i dati con tabella e valore come parametri
     * 
     * @param val
     * @param table
     * @return data 
     */
    public String getData(String val, String table) 
    {
        String url = "http://altf4rq.altervista.org/get.php?tab=" + table + "&param=*&where=" + val;
        String data = null;
        try 
        {
            data = conn.sendGet(url, "ricevimento");
        } 
        catch (Exception ex) 
        {
            Logger.getLogger(MyQuery.class.getName()).log(Level.SEVERE, null, ex);
        }

        return data;
    }
    
    /**
     * @brief Metodo che controlla le credenziali per assicurarsi che siano state inserite correttamente
     * 
     * @param username
     * @param password
     * @return msg contenente il messaggio
     */
    public String chkLogin(String username, String password) 
    {
        Map<Object, Object> data = new HashMap<>();
        
        data.put("tab", "altf4_utenti");
       
        data.put("username", username);

        MessageDigest md = null;

        try 
        {
            md = MessageDigest.getInstance("MD5");
        } 
        catch (NoSuchAlgorithmException ex) 
        {
            Logger.getLogger(MyQuery.class.getName()).log(Level.SEVERE, null, ex);
        }

        byte[] messageDigest = md.digest(password.getBytes());
        BigInteger no = new BigInteger(1, messageDigest);

        // Convert message digest into hex value
        String hashtext = no.toString(16);
        while (hashtext.length() < 32) 
        {
            hashtext = "0" + hashtext;
        }

        data.put("password", hashtext);

        String url = "http://altf4rq.altervista.org/chkLogin.php";

        String msg = "";

        try 
        {
            msg = conn.sendPost(url, "ricevimento", data);
        } 
        catch (Exception ex) 
        {
            Logger.getLogger(MyQuery.class.getName()).log(Level.SEVERE, null, ex);
        }

        return msg;
    }

    //--------------------------------------------------------------------------------
    /**
     * @brief Metodo che inserisce i dati per l'utilizzo tramite la classe \cUtilizzo
     * 
     * @param utilizzo
     * @return msg 
     */
    public String InserimentoUtilizzo(Utilizzo utilizzo) 
    {
        String msg = "";

        Map<Object, Object> data = new HashMap<>();
        data.put("table", "altf4_utilizzo");
        data.put("data", utilizzo.getData());
        data.put("oraIn", utilizzo.getOraIn());
        data.put("Destinazione", utilizzo.getDestinazione());
        data.put("idUtente", utilizzo.getIDUtente());
        data.put("targaAuto", utilizzo.getTarga());
        String url = "http://altf4rq.altervista.org/inserimentoImbro.php";

        try 
        {
            msg = conn.sendPost(url, "inserimento", data);
        } 
        catch (Exception ex) 
        {
            Logger.getLogger(MyQuery.class.getName()).log(Level.SEVERE, null, ex);
        }
        return msg;
    }
    
    /**
     * @brief Metodo che inserisce i dati per la prenotazione tramite la classe \cUtilizzo
     * 
     * @param utilizzo
     * @return msg
     */
    public String InserimentoPrenotazione(Utilizzo utilizzo) 
    {
        String msg = "";

        Map<Object, Object> data = new HashMap<>();
        data.put("table", "altf4_prenotazione");
        data.put("data", utilizzo.getData());
        data.put("oraIn", utilizzo.getOraIn());
        data.put("Destinazione", utilizzo.getDestinazione());
        data.put("idUtente", utilizzo.getIDUtente());
        data.put("targaAuto", utilizzo.getTarga());
        String url = "http://altf4rq.altervista.org/inserimentoImbro.php";

        try 
        {
            msg = conn.sendPost(url, "inserimento", data);
        } 
        catch (Exception ex) 
        {
            Logger.getLogger(MyQuery.class.getName()).log(Level.SEVERE, null, ex);
        }
        return msg;
    }
}