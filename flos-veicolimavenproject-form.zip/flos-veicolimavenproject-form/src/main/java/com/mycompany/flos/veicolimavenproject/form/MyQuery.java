/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.flos.veicolimavenproject.form;

import java.math.BigInteger;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.sql.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Francesco
 */
public class MyQuery {

    private MyConnection conn;

    public MyQuery() {

        conn = new MyConnection();
    }

    public String getData(String val, String table, String type) {

        String url = "";
        if (type == null) {
            url = "http://altf4rq.altervista.org/get.php?tab=" + table + "&param=*&where=" + val;
        } else {
            url = "http://altf4rq.altervista.org/get.php?tab=" + table + "&param=*&where=" + val+"&typeofwhere="+type;
        }

        String data = null;
        try {
            data = conn.sendGet(url, "ricevimento");
        } catch (Exception ex) {
            Logger.getLogger(MyQuery.class.getName()).log(Level.SEVERE, null, ex);
        }

        return data;
    }

    public String chkLogin(String username, String password) {

        Map<Object, Object> data = new HashMap<>();

        data.put("tab", "altf4_utenti");

        data.put("username", username);

        MessageDigest md = null;

        try {
            md = MessageDigest.getInstance("MD5");
        } catch (NoSuchAlgorithmException ex) {
            Logger.getLogger(MyQuery.class.getName()).log(Level.SEVERE, null, ex);
        }

        byte[] messageDigest = md.digest(password.getBytes());
        BigInteger no = new BigInteger(1, messageDigest);

        // Convert message digest into hex value
        String hashtext = no.toString(16);
        while (hashtext.length() < 32) {
            hashtext = "0" + hashtext;
        }

        data.put("password", hashtext);

        String url = "http://altf4rq.altervista.org/chkLogin.php";

        String msg = "";

        try {
            msg = conn.sendPost(url, "ricevimento", data);
        } catch (Exception ex) {
            Logger.getLogger(MyQuery.class.getName()).log(Level.SEVERE, null, ex);
        }

        return msg;
    }

    //--------------------------------------------------------------------------------
    public String InserimentoUtilizzo(Utilizzo utilizzo) {
        String msg = "";

        Map<Object, Object> data = new HashMap<>();
        data.put("table", "altf4_utilizzo");
        data.put("data", utilizzo.getData());
        data.put("oraIn", utilizzo.getOraIn());
        data.put("Destinazione", utilizzo.getDestinazione());
        data.put("idUtente", utilizzo.getIDUtente());
        data.put("targaAuto", utilizzo.getTarga());
        String url = "http://altf4rq.altervista.org/inserimentoImbro.php";

        try {
            msg = conn.sendPost(url, "inserimento", data);
        } catch (Exception ex) {
            Logger.getLogger(MyQuery.class.getName()).log(Level.SEVERE, null, ex);
        }
        return msg;
    }

    public String InserimentoPrenotazione(Utilizzo utilizzo) {
        String msg = "";

        Map<Object, Object> data = new HashMap<>();
        data.put("table", "altf4_prenotazione");
        data.put("data", utilizzo.getData());
        data.put("oraIn", utilizzo.getOraIn());
        data.put("Destinazione", utilizzo.getDestinazione());
        data.put("idUtente", utilizzo.getIDUtente());
        data.put("targaAuto", utilizzo.getTarga());
        String url = "http://altf4rq.altervista.org/inserimentoImbro.php";

        try {
            msg = conn.sendPost(url, "inserimento", data);
        } catch (Exception ex) {
            Logger.getLogger(MyQuery.class.getName()).log(Level.SEVERE, null, ex);
        }
        return msg;
    }

    public String getPrenotazioneFromData(Date data) {

        String url = "http://altf4rq.altervista.org/get.php?tab=altf4_prenotazione&param=*&where=" + data;
        String line = null;
        try {
            line = conn.sendGet(url, "ricevimento");
        } catch (Exception ex) {
            Logger.getLogger(MyQuery.class.getName()).log(Level.SEVERE, null, ex);
        }

        return line;
    }

    public String delete(String tab, String value) {

        String url = "http://altf4rq.altervista.org/delete.php?tab="+tab+"&ID=" + value;
        String line = null;
        try {
            line = conn.sendGet(url, "ricevimento");
        } catch (Exception ex) {
            Logger.getLogger(MyQuery.class.getName()).log(Level.SEVERE, null, ex);
        }

        return line;
    }

    public void update(String user, String campo, String tab, String val) {

        String msg2 = "";

        Map<Object, Object> data = new HashMap<>();
        data.put("table", tab);
        data.put("param", campo);
        data.put("ID", user);

        if ("password".equals(campo)) {

            MessageDigest md = null;

            try {
                md = MessageDigest.getInstance("MD5");
            } catch (NoSuchAlgorithmException ex) {
                Logger.getLogger(MyQuery.class.getName()).log(Level.SEVERE, null, ex);
            }

            byte[] messageDigest = md.digest(val.getBytes());
            BigInteger no = new BigInteger(1, messageDigest);

            // Convert message digest into hex value
            String hashtext = no.toString(16);
            while (hashtext.length() < 32) {
                hashtext = "0" + hashtext;
            }
            data.put("val", hashtext);
        } else {
            data.put("val", val);
        }

        String url = "http://altf4rq.altervista.org/update.php";

        try {
            msg2 = conn.sendPost(url, "inserimento", data);
        } catch (Exception ex) {
            Logger.getLogger(MyQuery.class.getName()).log(Level.SEVERE, null, ex);
        }

    }
}
