/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.flos.veicolimavenproject.form;

/**
 * @author Giovanni F. Cappellini
 * @version 1.0
 * @file Prenotazione.java
 * @brief Il file contiene la classe Prenotazione
 */

/**
 * @class Prenotazione
 * @brief La classe gestisce la prenotazione di un'auto aziendale
 */
class Prenotazione 
{
    /**Numero identificativo*/
    private String ID;
    
    /**Data della prenotazione*/
    private String data;
    
    /**Ora iniziale della prenotazione*/
    private String oraIn;
    
    /**Numero identificato dell'utente*/
    private String IDUtente;
    
    /**Targa di un'auto aziendale*/
    private String Targa;
    
    /**Destinazione in cui avviene la prenotazione*/
    private String Destinazione;
    
    /**
     * @brief Costruttore con parametri
     * 
     * @param ID
     * @param IDUtente
     * @param Targa
     * @param data
     * @param oraIn
     * @param Destinazione
     * 
     * Vengono inseriti i dati della prenotazione
     */
    public Prenotazione(String ID, String IDUtente, String Targa, String data, String oraIn, String Destinazione) 
    {
        this.ID = ID;
        this.data = data;
        this.oraIn = oraIn;
        this.IDUtente = IDUtente;
        this.Targa = Targa;
        this.Destinazione = Destinazione;
    }
    
    /**
     * @brief Metodo che restituisce l'ID
     * 
     * @return ID 
     */
    public String getID() 
    {
        return ID;
    }
    
    /**
     * @brief Metodo che modifica l'ID
     * 
     * @param ID 
     */
    public void setID(String ID) 
    {
        this.ID = ID;
    }
    
    /**
     * @brief Metodo che restituisce la data della prenotazione
     * 
     * @return data 
     */
    public String getData() 
    {
        return data;
    }
    
    /**
     * @brief Metodo che modfica la data della prenotazione
     * 
     * @param data 
     */
    public void setData(String data) 
    {
        this.data = data;
    }

    
    /**
     * @brief Metodo che restituisce l'ora iniziale
     * 
     * @return oraIn
     */
    public String getOraIn() 
    {
        return oraIn;
    }
    
    /**
     * @brief Metodo che modifica l'ora iniziale
     * 
     * @param oraIn 
     */
    public void setOraIn(String oraIn) 
    {
        this.oraIn = oraIn;
    }
    
    /**
     * @brief Metodo che restituisce l'ID dell'utente 
     * 
     * @return IDUtente 
     */
    public String getIDUtente() 
    {
        return IDUtente;
    }
    
    /**
     * @brief Metodo che modifica l'ID dell'utente
     * 
     * @param IDUtente 
     */
    public void setIDUtente(String IDUtente) 
    {
        this.IDUtente = IDUtente;
    }
    
    /**
     * @brief Metodo che restituisce la targa di un'auto aziendale interessata
     * 
     * @return Targa
     */
    public String getTarga() 
    {
        return Targa;
    }
    
    /**
     * @brief Metodo che restituisce la targa di un'auto aziendale
     * 
     * @param Targa 
     */
    public void setTarga(String Targa) 
    {
        this.Targa = Targa;
    }
    
    /**
     * @brief Metodo che restituisce la destinazione interessata
     * 
     * @return Destinazione
     */
    public String getDestinazione() 
    {
        return Destinazione;
    }
    
    /**
     * @brief Metodo che modifica la destinazione
     * 
     * @param Destinazione 
     */
    public void setDestinazione(String Destinazione) 
    {
        this.Destinazione = Destinazione;
    }
}
