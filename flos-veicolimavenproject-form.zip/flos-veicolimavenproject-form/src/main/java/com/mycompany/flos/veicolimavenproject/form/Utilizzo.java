/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.flos.veicolimavenproject.form;

import java.sql.Date;
import java.sql.Time;

/**
 * @author Giovanni F. Cappellini
 * @version 1.0
 * @file Utilizzo.java
 * @brief Il file Utilizzo.java contiene la classe Utilizzo
 */

/**
 * @class Utilizzo
 * 
 * @brief La classe gestisce le caratteristiche dell'utilizzo di un'auto aziendale
 */
public class Utilizzo 
{
   /**Numero identificativo dell'utilizzo*/
    private String ID;
    
    /**Data in cui avviene l'utilizzo*/
    private String data;
    
    /**Ora che inizia l'utilizzo*/
    private String oraIn;
    
    /**Ora che termina l'utilizzo*/
    private String oraOut;
    
    /**Numero identificativo dell'utente interessato all'utilizzo*/
    private String IDUtente;
    
    /**Targa di un'auto aziendale coinvolta nell'utilizzo*/
    private String Targa;
    
    /**Destinazione*/
    private String Destinazione;
    
    //private String motivo;
    
    /**
     * @brief Costruttore di default
     * 
     * Vengono inizializzati gli attributi
     */
    public Utilizzo() 
    {
        this.ID = "";
        this.data = null;
        this.oraIn = null;
        this.oraOut = null;
        this.IDUtente = "";
        this.Targa = "";
        this.Destinazione = "";
    }
    
    /**
     * @brief Costruttore con parametri (senza il parametro \cDestinazione)
     * 
     * @param ID
     * @param data
     * @param oraIn
     * @param oraOut
     * @param IDUtente
     * @param Targa 
     * 
     * Vengono inseriti i dati tramite i parametri \cID, \cdata, \coraIn, \coraOut, \cIDUtente e \cTarga
     */
    public Utilizzo(String ID, String data, String oraIn, String oraOut, String IDUtente, String Targa) 
    {
        this.ID = ID;
        this.data = data;
        this.oraIn = oraIn;
        this.oraOut = oraOut;
        this.IDUtente = IDUtente;
        this.Targa = Targa;   
    }
    
    /**
     * @brief Costruttore con parametri (con il parametro \cDestinazione)
     * 
     * @param ID
     * @param data
     * @param oraIn
     * @param oraOut
     * @param IDUtente
     * @param Targa
     * @param Destinazione 
     * 
     * Vengono inseriti i dati tramite parametri \cID, \cdata, \coraIn, \coraOut, \cIDUtente, \cTarga, \cDestinazione
     */
    public Utilizzo(String ID, String data, String oraIn, String oraOut, String IDUtente, String Targa, String Destinazione) 
    {
        this.ID = ID;
        this.data = data;
        this.oraIn = oraIn;
        this.oraOut = oraOut;
        this.IDUtente = IDUtente;
        this.Targa = Targa;
        this.Destinazione = Destinazione;
        //this.motivo=motivo;
    }
    
    /**
     * @brief Metodo che restituisce l'ID
     * 
     * @return ID
     */
    public String getID() 
    {
        return ID;
    }
    
    /**
     * @brief Metodo che restiuisce la destinazione specificata
     * 
     * @return Destinazione
     */
    public String getDestinazione() 
    {
        return Destinazione;
    }
    
    /**
     * @brief Metodo che modifica l'ID con \cID passato come parametro
     *
     * @param ID 
     */
    public void setID(String ID) 
    {
        this.ID = ID;
    }
    
    /**
     * @brief Metodo che restituisce la data in cui avviene l'utilizzo
     * 
     * @return data
     */
    public String getData() 
    {
        return data;
    }
    
    /**
     * @brief Metodo che modifica la data in cui avviene l'utilizzo con \cdata passata come parametro
     * 
     * @param data 
     */
    public void setData(String data) 
    {
        this.data = data;
    }
    
    /**
     * @brief Metodo che restituisce l'ora iniziale dell'utilizzo
     * 
     * @return oraIn
     */
    public String getOraIn() 
    {
        return oraIn;
    }
    
    /**
     * @brief Metodo che modifica l'ora finale dell'utilizzo con \coraOut passata come parametro
     * 
     * @param oraIn 
     */
    public void setOraIn(String oraIn) 
    {
        this.oraIn = oraIn;
    }
    
    /**
     * @brief Metodo che restituisce l'ora finale dell'utilizzo
     * 
     * @return oraOut
     */
    public String getOraOut() 
    {
        return oraOut;
    }
    
    /**
     * @brief Metodo che modifica l'ora finale dell'utilizzo con \coraOut passata come parametro
     * 
     * @param oraOut 
     */
    public void setOraOut(String oraOut) 
    {
        this.oraOut = oraOut;
    }
    
    /**
     * @brief Metodo che restituisce l'ID dell'utente interessato all'utilizzo
     * 
     * @return IDUtente
     */
    public String getIDUtente() 
    {
        return IDUtente;
    }
    
    /**
     * @brief Metodo che modifica l'ID dell'utente con \cIDUtente passato come parametro
     * 
     * @param IDUtente 
     */
    public void setIDUtente(String IDUtente) 
    {
        this.IDUtente = IDUtente;
    }
    
    /**
     * @brief Metodo che restituisce la targa di un'auto aziendale coinvolta nell'utilizzo
     * 
     * @return Targa
     */
    public String getTarga() 
    {
        return Targa;
    }
    
    /**
     * @brief Metodo che modifica la targa di un'auto aziendale con \cTarga passata come parametro
     * 
     * @param Targa 
     */
    public void setTarga(String Targa) 
    {
        this.Targa = Targa;
    }
}