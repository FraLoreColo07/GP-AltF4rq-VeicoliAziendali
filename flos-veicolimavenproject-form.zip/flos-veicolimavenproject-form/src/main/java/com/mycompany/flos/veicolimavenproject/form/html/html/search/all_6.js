var searchData=
[
  ['httpclient',['httpClient',['../classcom_1_1mycompany_1_1flos_1_1veicolimavenproject_1_1form_1_1_my_connection.html#a8a8a60f9391523eeb735a05a62d4312b',1,'com::mycompany::flos::veicolimavenproject::form::MyConnection']]]
];
