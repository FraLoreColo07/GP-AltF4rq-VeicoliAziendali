var searchData=
[
  ['query',['query',['../classcom_1_1mycompany_1_1flos_1_1veicolimavenproject_1_1form_1_1form_login.html#add613f88d03db1e7f72e289e33976b9e',1,'com.mycompany.flos.veicolimavenproject.form.formLogin.query()'],['../classcom_1_1mycompany_1_1flos_1_1veicolimavenproject_1_1form_1_1form_veicoli.html#add613f88d03db1e7f72e289e33976b9e',1,'com.mycompany.flos.veicolimavenproject.form.formVeicoli.query()']]]
];
